import numpy as np
import mxnet as mx
import sys
sys.path.insert(0, './source_dir')
import mnist as mn

model_dir = './checkpoints'
test_data_dir = './data'

test_data = mn.get_val_data(test_data_dir, 100)
nn = mn.model_fn(model_dir)

result = mn.test(mx.cpu(), nn, test_data)

print result
