import numpy as np
import mxnet as mx
import sys
sys.path.insert(0, './source_dir')
import mnist as mn

model_dir = './checkpoints'
test_data_dir = './data'

test_labels, test_images = mn.load_data(test_data_dir)
val_iter = mx.io.NDArrayIter(test_images, test_labels, batch_size=100)

sym, arg_params, aux_params = mx.model.load_checkpoint('%s/model' % model_dir, 0)
nn = mx.mod.Module(symbol=sym, context=mx.cpu(), label_names=None)
nn.bind(for_training=False, data_shapes=val_iter.provide_data, label_shapes=val_iter.provide_label)
nn.set_params(arg_params, aux_params, allow_missing=True)

result = nn.score(val_iter, ['acc'])
print result
