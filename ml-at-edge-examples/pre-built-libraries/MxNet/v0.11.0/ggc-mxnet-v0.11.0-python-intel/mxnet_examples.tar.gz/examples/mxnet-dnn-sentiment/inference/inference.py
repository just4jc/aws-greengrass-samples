import numpy as np
import mxnet as mx
import sys
sys.path.insert(0, './source_dir')
import sentiment as se

model_dir = './checkpoints'
test_data_dir = './data'

train_sentences, train_labels, _ = se.get_dataset(test_data_dir + '/train')
val_sentences, val_labels, _ = se.get_dataset(test_data_dir + '/test')
vocab = se.create_vocab(train_sentences)
val_sentences = [[vocab.get(token, 1) for token in line if len(line)>0] for line in val_sentences]
val_iterator = se.BucketSentenceIter(val_sentences, val_labels, 8)

nn = se.model_fn(model_dir)[0]
result = se.test(mx.cpu(), nn, val_iterator)

print result
