import numpy as np
import tensorflow as tf
import sys
sys.path.insert(0, './source_dir')
import resnet_cifar_10 as resnet

model_dir = './checkpoints'
test_data_dir = './data'

# The model in this repo has a low accuracy as we use fewer training steps.
# To increase the accuracy, you can increase training_steps in training.ipynb
# and retrain the model.
nn = tf.estimator.Estimator(model_fn=resnet.model_fn, model_dir=model_dir, params=None)

result = nn.evaluate(input_fn=lambda:resnet.eval_input_fn(test_data_dir, None))
print result
