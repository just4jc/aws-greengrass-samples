import tensorflow as tf
import os
import numpy as np
import cv2
import sys

model_dir = "checkpoints/"
data_dir = "data/"
classes = ['dogs','cats']

image_size=128
num_channels=3

# import the frozen graph 
with tf.gfile.GFile(model_dir + "frozen_graph.pb", "rb") as f:
      graph_def = tf.GraphDef()
      graph_def.ParseFromString(f.read())
 
with tf.Graph().as_default() as graph:
      tf.import_graph_def(graph_def, input_map=None, return_elements=None, name="")

# import the input and output tensors based on the name
y_pred = graph.get_tensor_by_name("y_pred:0")
x= graph.get_tensor_by_name("x:0")
y_test_images = np.zeros((1, 2))
sess= tf.Session(graph=graph)

# for each image in the data_dir, read the image, process the data and do the prediction.
# print the image filename, and the predicted labels
for filename in os.listdir(data_dir):
    image = cv2.imread(data_dir + filename)
    image = cv2.resize(image, (image_size, image_size), interpolation=cv2.INTER_LINEAR)
    image = np.array(image, dtype=np.uint8)
    image = image.astype('float32')
    image = np.multiply(image, 1.0/255.0)
    x_batch = image.reshape(1, image_size, image_size, num_channels)
 
    feed_dict_testing = {x: x_batch}
    result=sess.run(y_pred, feed_dict=feed_dict_testing)
    print("Pic {0} -- Prediction results: {1}".format(filename, classes[np.argmax(result)]))
