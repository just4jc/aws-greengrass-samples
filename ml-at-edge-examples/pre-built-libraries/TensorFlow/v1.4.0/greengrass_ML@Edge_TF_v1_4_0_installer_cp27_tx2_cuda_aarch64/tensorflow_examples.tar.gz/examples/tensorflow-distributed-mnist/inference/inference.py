import numpy as np
import tensorflow as tf
import sys
sys.path.insert(0, './source_dir')
import mnist as mn

model_dir = './checkpoints'
test_data_dir = './data'

nn = tf.estimator.Estimator(model_fn=mn.model_fn, model_dir=model_dir, params={'learning_rate': 0.001})

result = nn.evaluate(input_fn=lambda:mn.eval_input_fn(test_data_dir, None))
print result
