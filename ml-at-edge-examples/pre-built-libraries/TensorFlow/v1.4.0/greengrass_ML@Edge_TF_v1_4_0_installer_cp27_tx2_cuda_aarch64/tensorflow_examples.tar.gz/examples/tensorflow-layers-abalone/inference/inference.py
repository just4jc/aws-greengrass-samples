import numpy as np
import tensorflow as tf
import sys
sys.path.insert(0, './source_dir')
import abalone as ab

model_dir = './checkpoints'
test_data_dir = './data'

nn = tf.estimator.Estimator(model_fn=ab.model_fn, model_dir=model_dir, params={'learning_rate': 0.001})

result = nn.evaluate(input_fn=lambda:ab.eval_input_fn(test_data_dir, None))
print result
