import numpy as np
import tensorflow as tf
import sys
sys.path.insert(0, './source_dir')
import dnn_iris as dnn

from tensorflow.contrib.learn.python.learn.estimators import run_config

model_dir = './checkpoints'
test_data_dir = './data'

config = run_config.RunConfig(model_dir=model_dir)
nn = dnn.estimator_fn(config, None)

result = nn.evaluate(input_fn=lambda:dnn.eval_input_fn(test_data_dir, None))
print result
